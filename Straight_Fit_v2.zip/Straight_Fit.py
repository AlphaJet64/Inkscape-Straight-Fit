import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import inkex
from inkex import units, Layer
from inkex.elements import Image as InkImage
from PIL import Image
from io import BytesIO
import base64
import numpy as np
import os
from lxml import etree

formats = {
    'A4': {'width': 210.0, 'height': 297.0, 'unit': 'mm'},
    'US Letter': {'width': 8.5, 'height': 11.0, 'unit': 'in'},
    'US Legal': {'width': 8.5, 'height': 14.0, 'unit': 'in'},
    'US Executive': {'width': 7.25, 'height': 10.5, 'unit': 'in'},
    'US Ledger/Tabloid': {'width': 11.0, 'height': 17.0, 'unit': 'in'},
    'A0': {'width': 841.0, 'height': 1189.0, 'unit': 'mm'},
    'A1': {'width': 594.0, 'height': 841.0, 'unit': 'mm'},
    'A2': {'width': 420.0, 'height': 594.0, 'unit': 'mm'},
    'A3': {'width': 297.0, 'height': 420.0, 'unit': 'mm'},
    'A5': {'width': 148.0, 'height': 210.0, 'unit': 'mm'},
    'A6': {'width': 105.0, 'height': 148.0, 'unit': 'mm'},
    'A7': {'width': 74.0, 'height': 105.0, 'unit': 'mm'},
    'A8': {'width': 52.0, 'height': 74.0, 'unit': 'mm'},
    'A9': {'width': 37.0, 'height': 52.0, 'unit': 'mm'},
    'A10': {'width': 26.0, 'height': 37.0, 'unit': 'mm'},
    'B0': {'width': 1000.0, 'height': 1414.0, 'unit': 'mm'},
    'B1': {'width': 707.0, 'height': 1000.0, 'unit': 'mm'},
    'B2': {'width': 500.0, 'height': 707.0, 'unit': 'mm'},
    'B3': {'width': 353.0, 'height': 500.0, 'unit': 'mm'},
    'B4': {'width': 250.0, 'height': 353.0, 'unit': 'mm'},
    'B5': {'width': 176.0, 'height': 250.0, 'unit': 'mm'},
    'B6': {'width': 125.0, 'height': 176.0, 'unit': 'mm'},
    'B7': {'width': 88.0, 'height': 125.0, 'unit': 'mm'},
    'B8': {'width': 62.0, 'height': 88.0, 'unit': 'mm'},
    'B9': {'width': 44.0, 'height': 62.0, 'unit': 'mm'},
    'B10': {'width': 31.0, 'height': 44.0, 'unit': 'mm'},
    'C0': {'width': 917.0, 'height': 1297.0, 'unit': 'mm'},
    'C1': {'width': 648.0, 'height': 917.0, 'unit': 'mm'},
    'C2': {'width': 458.0, 'height': 648.0, 'unit': 'mm'},
    'C3': {'width': 324.0, 'height': 458.0, 'unit': 'mm'},
    'C4': {'width': 229.0, 'height': 324.0, 'unit': 'mm'},
    'C5': {'width': 162.0, 'height': 229.0, 'unit': 'mm'},
    'C6': {'width': 114.0, 'height': 162.0, 'unit': 'mm'},
    'C7': {'width': 81.0, 'height': 114.0, 'unit': 'mm'},
    'C8': {'width': 57.0, 'height': 81.0, 'unit': 'mm'},
    'C9': {'width': 40.0, 'height': 57.0, 'unit': 'mm'},
    'C10': {'width': 28.0, 'height': 40.0, 'unit': 'mm'},
    'D1': {'width': 545.0, 'height': 771.0, 'unit': 'mm'},
    'D2': {'width': 385.0, 'height': 545.0, 'unit': 'mm'},
    'D3': {'width': 272.0, 'height': 385.0, 'unit': 'mm'},
    'D4': {'width': 192.0, 'height': 272.0, 'unit': 'mm'},
    'D5': {'width': 136.0, 'height': 192.0, 'unit': 'mm'},
    'D6': {'width': 96.0, 'height': 136.0, 'unit': 'mm'},
    'D7': {'width': 68.0, 'height': 96.0, 'unit': 'mm'},
    'E3': {'width': 400.0, 'height': 560.0, 'unit': 'mm'},
    'E4': {'width': 280.0, 'height': 400.0, 'unit': 'mm'},
    'E5': {'width': 200.0, 'height': 280.0, 'unit': 'mm'},
    'E6': {'width': 140.0, 'height': 200.0, 'unit': 'mm'},
    'CSE': {'width': 462.0, 'height': 649.0, 'unit': 'pt'},
    'US #10 Envelope': {'width': 9.5, 'height': 4.125, 'unit': 'in'},
    'DL Envelope': {'width': 220.0, 'height': 110.0, 'unit': 'mm'},
    'Banner 468x60': {'width': 468.0, 'height': 60.0, 'unit': 'px'},
    'Icon 16x16': {'width': 16.0, 'height': 16.0, 'unit': 'px'},
    'Icon 32x32': {'width': 32.0, 'height': 32.0, 'unit': 'px'},
    'Icon 48x48': {'width': 48.0, 'height': 48.0, 'unit': 'px'},
    'ID Card (ISO 7810)': {'width': 85.6, 'height': 53.98, 'unit': 'mm'},
    'Business Card (US)': {'width': 3.5, 'height': 2.0, 'unit': 'in'},
    'Business Card (Europe)': {'width': 85.0, 'height': 55.0, 'unit': 'mm'},
    'Business Card (AU/NZ)': {'width': 90.0, 'height': 55.0, 'unit': 'mm'},
    'Arch A': {'width': 9.0, 'height': 12.0, 'unit': 'in'},
    'Arch B': {'width': 12.0, 'height': 18.0, 'unit': 'in'},
    'Arch C': {'width': 18.0, 'height': 24.0, 'unit': 'in'},
    'Arch D': {'width': 24.0, 'height': 36.0, 'unit': 'in'},
    'Arch E': {'width': 36.0, 'height': 48.0, 'unit': 'in'},
    'Arch E1': {'width': 30.0, 'height': 42.0, 'unit': 'in'},
    'Video SD / PAL': {'width': 768.0, 'height': 576.0, 'unit': 'px'},
    'Video SD-Widescreen / PAL': {'width': 1024.0, 'height': 576.0, 'unit': 'px'},
    'Video SD / NTSC': {'width': 544.0, 'height': 480.0, 'unit': 'px'},
    'Video SD-Widescreen / NTSC': {'width': 872.0, 'height': 486.0, 'unit': 'px'},
    'Video HD 720p': {'width': 1280.0, 'height': 720.0, 'unit': 'px'},
    'Video HD 1080p': {'width': 1920.0, 'height': 1080.0, 'unit': 'px'},
    'Video DCI 2k (Full Frame)': {'width': 2048.0, 'height': 1080.0, 'unit': 'px'},
    'Video UHD 4k': {'width': 3840.0, 'height': 2160.0, 'unit': 'px'},
    'Video DCI 4k (Full Frame)': {'width': 4096.0, 'height': 2160.0, 'unit': 'px'},
    'Video UHD 8k': {'width': 7680.0, 'height': 4320.0, 'unit': 'px'},
    'Custom size': {'width': 300, 'height': 300, 'unit': 'px'}
}

units_svg = ['px', 'mm', 'cm', 'in', 'ft', 'pt', 'pc']

class ImageDialog(tk.Tk):
    def __init__(self, image_element, path_element, svg_root):
        super().__init__()
        # Windows 
        self.title("Preview of the straightened image")
        self.attributes('-topmost', 1)
        self.geometry('570x320')
        self.center_window()
        self.resizable(False, False)

        self.svg_root = svg_root
        page_width = units.convert_unit(svg_root.attrib.get('width'), svg_root.unit)
        page_height = units.convert_unit(svg_root.attrib.get('height'), svg_root.unit)
        page_format = self.get_format(page_width, page_height, svg_root.unit)

        self.page_unit = svg_root.unit
        self.orientation_image_var = tk.IntVar(value=0)
        self.page_format_var = tk.StringVar(value=page_format)
        self.page_width_var = tk.StringVar(value=str(page_width))
        self.page_height_var = tk.StringVar(value=str(page_height))
        self.page_unit_var = tk.StringVar(value=svg_root.unit)
        self.orientation_var = tk.IntVar(value=0)

        self.create_widgets()

        self.image_element = image_element
        self.path_element = path_element
        self.photo_image = self.load_imagePIL(image_element)
        self.img_transformed = None
        
        self.orientation_var.set(1 if page_width > page_height else 0)

        self.update()
        
    def center_window(self):
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry('{}x{}+{}+{}'.format(width, height, x, y))
        
    def extract_number_and_unit(self, s):
        letter_count = sum(char.isalpha() for char in reversed(s))
        if letter_count > 0:
            number = s[:-letter_count].strip()
            unit = s[-letter_count:]
            return float(number), unit
        return float(s), ""

    def permutation(self, points, value):
        return points[value:] + points[:value]

    def sort_points(self, points):
        top = sorted(points, key=lambda p: p[1])[:2]
        bottom = sorted(points, key=lambda p: p[1])[-2:]
        top_sorted = sorted(top, key=lambda p: p[0])
        bottom_sorted = sorted(bottom, key=lambda p: p[0])
        return [top_sorted[0]] + bottom_sorted + [top_sorted[1]]

    def load_imagePIL(self, image_element):
        href = image_element.get('{http://www.w3.org/1999/xlink}href')
        if href and href.startswith('data:image/'):
            mime_type, data = href.split(',', 1)
            decoded_data = base64.b64decode(data)
            try:
                return Image.open(BytesIO(decoded_data))
            except Exception:
                return None
        return None

    def coordonnees_decoupe(self, image_element, img_size, path_data):
        image_x = float(image_element.get('x', 0))
        image_y = float(image_element.get('y', 0))
        image_width = float(image_element.get('width', 1))
        image_height = float(image_element.get('height', 1))
        real_width, real_height = img_size
        if real_width and real_height:
            scale_x = real_width / image_width
            scale_y = real_height / image_height
            return [((x - image_x) * scale_x, (y - image_y) * scale_y) for x, y in path_data]
        return []

    def transform_image(self, img, points, width, height):
        destination_points = [(0, 0), (int(width), 0), (int(width), int(height)), (0, int(height))]
        matrix = np.array(points + destination_points).flatten()
        return img.transform((int(width), int(height)), Image.QUAD, data=matrix, resample=Image.BICUBIC)

    def extract_dimension(self, dimension_text):
        if dimension_text:
            value = ''.join([c for c in dimension_text if c.isdigit() or c == '.'])
            return float(value)
        return 0.0

    def create_widgets(self):
        left_frame = tk.Frame(self, width=300, height=300, bg="lightgrey")
        left_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        left_frame.grid_propagate(False)

        self.canvas = tk.Canvas(left_frame, width=300, height=300, bg=self.cget("bg"))
        self.canvas.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

        right_frame = tk.Frame(self, width=230, height=300)
        right_frame.grid(row=0, column=1, padx=10, pady=5, sticky="nsew")
        right_frame.grid_propagate(False)

        orientation_image_frame = tk.Frame(right_frame)
        orientation_image_frame.grid(row=0, column=0, pady=10, padx=10, sticky="nsew")

        tk.Label(orientation_image_frame, text="Orientation of the image →").grid(row=1, column=1)
        tk.Radiobutton(orientation_image_frame, text="↑", variable=self.orientation_image_var, value=0, command=self.update).grid(row=0, column=1)
        tk.Radiobutton(orientation_image_frame, text="←", variable=self.orientation_image_var, value=1, command=self.update).grid(row=1, column=0)
        tk.Radiobutton(orientation_image_frame, text="", variable=self.orientation_image_var, value=3, command=self.update).grid(row=1, column=2)
        tk.Radiobutton(orientation_image_frame, text="↓", variable=self.orientation_image_var, value=2, command=self.update).grid(row=2, column=1)

        tk.Label(right_frame, text="Dimensions of the straightened image").grid(row=1, column=0, sticky="w")
        format_menu = ttk.Combobox(right_frame, textvariable=self.page_format_var, values=list(formats.keys()))
        format_menu.grid(row=2, column=0, padx=30, pady=5, sticky="nsew")
        format_menu.bind("<<ComboboxSelected>>", self.update_format)

        orientation = tk.Frame(right_frame)
        orientation.grid(row=3, column=0, pady=5, sticky="w")
        tk.Label(orientation, text="Orientation:").grid(row=0, column=0, sticky="w", padx=(0, 10))
        tk.Radiobutton(orientation, text="Portrait", variable=self.orientation_var, value=0, command=self.update_orientation).grid(row=0, column=1, sticky="w")
        tk.Radiobutton(orientation, text="Landscape", variable=self.orientation_var, value=1, command=self.update_orientation).grid(row=0, column=2, sticky="w")

        dimensions_frame = tk.Frame(right_frame)
        dimensions_frame.grid(row=4, column=0, pady=5, sticky="w")

        # Label et Entry pour la largeur
        tk.Label(dimensions_frame, text="Width:").grid(row=0, column=0, sticky="e", padx=(0, 15))
        self.largeur_entry = tk.Entry(dimensions_frame, textvariable=self.page_width_var, width=10)
        self.largeur_entry.grid(row=0, column=1, pady=5, sticky="w", padx=(0, 15))
        self.largeur_entry.bind("<FocusIn>", self.select_all_text)
        self.largeur_entry.bind("<Return>", lambda event: self.handle_return(event, self.hauteur_entry))

        # Label et Entry pour la hauteur
        tk.Label(dimensions_frame, text="Height:").grid(row=1, column=0, sticky="e", padx=(0, 15))
        self.hauteur_entry = tk.Entry(dimensions_frame, textvariable=self.page_height_var, width=10)
        self.hauteur_entry.grid(row=1, column=1, pady=5, sticky="w", padx=(0, 15))
        self.hauteur_entry.bind("<FocusIn>", self.select_all_text)
        self.hauteur_entry.bind("<Return>", lambda event: self.handle_return(event, self.largeur_entry))


        tk.Label(dimensions_frame, text="Unit:").grid(row=0, column=2, sticky="e", padx=(0, 25))
        unite_combo = ttk.Combobox(dimensions_frame, textvariable=self.page_unit_var, values=units_svg, width=5)
        unite_combo.grid(row=1, column=2, pady=5, sticky="w", padx=(20, 20))
        unite_combo.set(self.page_unit_var.get())
        unite_combo.bind("<<ComboboxSelected>>", self.update_units)

        button_frame = tk.Frame(right_frame)
        button_frame.grid(row=10, column=0, pady=15, sticky="nsew")
        button_frame.columnconfigure(0, weight=1)
        button_frame.columnconfigure(1, weight=1)

        cancel_button = tk.Button(button_frame, text="Cancel", command=self.cancel)
        cancel_button.grid(row=0, column=0, sticky="w", padx=30)

        save_button = tk.Button(button_frame, text="Save", command=self.save)
        save_button.grid(row=0, column=1, sticky="w", padx=5)

    def select_all_text(self, event):
        event.widget.select_range(0, tk.END)

    def handle_return(self, event, next_widget):
        self.switch_focus(next_widget)
        self.update_dim(event)

    def switch_focus(self, next_widget):
        next_widget.focus_set()
        inkex.utils.debug("Focus switched")

    def update_dim(self, event):
        width = self.page_width_var.get()
        height = self.page_height_var.get()
        unit = self.page_unit_var.get()
        self.orientation_var.set(1 if width > height else 0)
        format_trouve = "Custom size"
        format_trouve = self.get_format(width, height, unit)
        self.page_format_var.set(format_trouve)

        self.canvas.focus_set()
        self.update()
        
    def update(self):
        try:
            orientation_value = self.orientation_var.get()
            orientation_image_value = self.orientation_image_var.get()
            page_format_value = self.page_format_var.get()
            page_width_value = float(self.page_width_var.get())
            page_height_value = float(self.page_height_var.get())
            page_unit_value = self.page_unit_var.get()
            image_width_px = int(units.convert_unit(str(page_width_value) + page_unit_value, 'px'))
            image_height_px = int(units.convert_unit(str(page_height_value) + page_unit_value, 'px'))

            end_points_list = list(self.path_element.path.transform(self.path_element.composed_transform()).end_points)
            end_points = [(point.x, point.y) for point in end_points_list[:4]]
            sorted_points = self.permutation(self.sort_points(end_points), orientation_image_value)
            self.points_decoupe = self.coordonnees_decoupe(self.image_element, self.photo_image.size, sorted_points)

            self.img_transformed = self.transform_image(self.photo_image, self.points_decoupe, image_width_px, image_height_px)
            self.display_image(self.canvas, self.img_transformed)
        except ValueError:
            print("Error converting width.")

    def display_image(self, canvas, img):
        if img is None:
            return
        self.update_idletasks()
        canvas_width = canvas.winfo_width()
        canvas_height = canvas.winfo_height()
        img_width, img_height = img.size
        ratio = min(canvas_width / img_width, canvas_height / img_height)
        new_width = int(img_width * ratio)
        new_height = int(img_height * ratio)

        resized_img = img.resize((new_width, new_height), Image.LANCZOS)
        resized_img_bytes = BytesIO()
        resized_img.save(resized_img_bytes, format="PNG")
        resized_img_bytes.seek(0)

        photo = tk.PhotoImage(data=resized_img_bytes.getvalue())
        x = (canvas_width - new_width) // 2
        y = (canvas_height - new_height) // 2
        canvas.create_image(x, y, anchor=tk.NW, image=photo)
        canvas.image = photo



    def convertir_en_mm(self, largeur, hauteur, unite):
        largeur = inkex.units.convert_unit(str(largeur) + unite, 'mm')
        hauteur = inkex.units.convert_unit(str(hauteur) + unite, 'mm')
        return largeur, hauteur

    def get_format(self, largeur, hauteur, unite, tolerance=0.2):
        format_trouve = "Custom size"
        largeur_mm, hauteur_mm = self.convertir_en_mm(largeur, hauteur, unite)

        if largeur_mm > hauteur_mm:
            largeur_mm, hauteur_mm = hauteur_mm, largeur_mm

        for format_name, format_data in formats.items():
            format_largeur_mm, format_hauteur_mm = self.convertir_en_mm(
                format_data['width'], format_data['height'], format_data['unit'])

            if (abs(format_largeur_mm - largeur_mm) <= tolerance and
                abs(format_hauteur_mm - hauteur_mm) <= tolerance):
                format_trouve = format_name
                break

        return format_trouve

    def update_units(self, event=None):
        nouvelle_unite = self.page_unit_var.get()
        round_unit = 2 if nouvelle_unite != 'px' else 0
        
        largeur = self.page_width_var.get()
        hauteur = self.page_height_var.get()

        largeur_convertie = units.convert_unit(str(largeur) + self.page_unit, nouvelle_unite)
        hauteur_convertie = units.convert_unit(str(hauteur) + self.page_unit, nouvelle_unite)

        self.page_width_var.set(round(largeur_convertie, round_unit))
        self.page_height_var.set(round(hauteur_convertie, round_unit))
        
        self.page_unit=nouvelle_unite

        self.canvas.focus_set()
        self.update()

    def update_format(self, event=None):
        selected_format = self.page_format_var.get()

        format_info = formats[selected_format]
        self.page_unit_var.set(format_info["unit"])
        if self.orientation_var.get() == 0:
            self.page_width_var.set(str(format_info['width']))
            self.page_height_var.set(str(format_info['height']))
        else:
            self.page_width_var.set(str(format_info['height']))
            self.page_height_var.set(str(format_info['width']))

        self.canvas.focus_set()
        self.update()

    def update_orientation(self):
        width = self.page_width_var.get()
        height = self.page_height_var.get()
        self.page_width_var.set(height)
        self.page_height_var.set(width)
        self.canvas.focus_set()
        self.update()

    def cancel(self):
        messagebox.showinfo("Cancelled", "No changes")
        self.destroy()

    def get_supported_extensions(self):
        extensions = Image.registered_extensions()
        return [(f"{ext.upper()} files", f"*{ext}") for ext in extensions]

    def get_image_path(self, filename):
        user_folder = os.path.expanduser('~')
        possible_image_folders = ['Images', 'images', 'Pictures', 'pictures']
        for folder in possible_image_folders:
            image_folder = os.path.join(user_folder, folder)
            if os.path.isdir(image_folder):
                return os.path.join(image_folder, filename)
        return os.path.join(user_folder, 'Images', filename)

    def save(self):
        user_images_dir = next((os.path.join(os.path.expanduser('~'), folder) for folder in ['Images', 'images', 'Pictures', 'pictures'] if os.path.isdir(os.path.join(os.path.expanduser('~'), folder))), os.path.expanduser('~'))

        layer = Layer()
        layer.label = "redressement"
        self.svg_root.add(layer)

        buffer = BytesIO()
        self.img_transformed.save(buffer, format="PNG")
        buffer.seek(0)

        image_data = base64.b64encode(buffer.getvalue()).decode('utf-8')

        new_image = InkImage()
        new_image.set('xlink:href', f"data:image/png;base64,{image_data}")
        new_image.set('x', 0)
        new_image.set('y', 0)
        width = float(self.page_width_var.get())
        height = float(self.page_height_var.get())
        new_image.set('width', width)
        new_image.set('height', height)

        layer.add(new_image)

        supported_extensions = self.get_supported_extensions()

        file_path = filedialog.asksaveasfilename(
            initialdir=user_images_dir,
            initialfile="Straight.png",
            defaultextension=".png",
            filetypes=supported_extensions)

        if file_path:
            self.img_transformed.save(file_path)
            messagebox.showinfo("Save successful", file_path)
        self.destroy()

class StraightFit(inkex.EffectExtension):
    def get_selection(self):
        if len(self.svg.selection) != 2:
            raise ValueError("Please select exactly two elements an image and a path.")

        image_element = None
        path_element = None

        for element in self.svg.selection:
            tag_name = element.tag.split('}')[-1]
            if tag_name == 'image':
                image_element = element
            elif tag_name == 'path':
                path_element = element

        if image_element is None or path_element is None:
            raise ValueError("Selection must contain exactly one image and one path.")

        return image_element, path_element, self.svg.root

    def effect(self):
        try:
            image_element, path_element, root = self.get_selection()
            dialog = ImageDialog(image_element, path_element, root)
            dialog.mainloop()
        except ValueError as e:
            inkex.utils.debug(e)

if __name__ == '__main__':
    StraightFit().run()
